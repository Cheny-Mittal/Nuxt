<template>
  <div>
    <NuxtWelcome />
  </div>
</template>
